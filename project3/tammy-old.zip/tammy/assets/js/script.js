$(document).ready(function(){

  $('.light').click(function(){
    $('body').css('background', '#ED1A4C');
  });

});